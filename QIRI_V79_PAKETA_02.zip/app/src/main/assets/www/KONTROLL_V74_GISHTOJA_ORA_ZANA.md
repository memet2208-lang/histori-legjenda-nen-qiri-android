# V74 — Kontroll redaksional i Gishtojës dhe Orës/Zanës

**Baza:** V73. **APK nuk preket.** Masteri shqip i leximit dhe përkthimet përditësohen; V48 arkivor dhe WebP e miratuara mbeten të paprekura.

## Ndryshime të kryera

- **38:** U plotësua fjalia e paplotë për gurin në tekstin shqip.
- **39:** U qartësua se kalojnë vitet, jo se Gishtoja ndryshon shtatin; italishtja, frëngjishtja dhe spanjishtja u harmonizuan. Anglishtja dhe gjermanishtja ishin tashmë të qarta.
- **42:** Gabimi shqip `u zgjuarsinë` u korrigj në `e kërkuan`.
- **44:** U saktësua se Ora është emri i djalit në këtë rrëfim; u ndreqën `Zhanat`, `ajo zë melodi`, dhe forma jo standarde `kish`.
- **45:** Fillon shprehimisht një tjetër tregim malësie me Lekën, jo vazhdim i episodit me djalin Ora; u harmonizua në pesë gjuhë. U korrigjuan formulimet për kalin në shqip.
- **46:** U përmirësua gramatika e përfundimit në shqip pa ndryshuar moralin e rrëfimit.

## Çështje të pambyllura para botimit

1. **Gishtoja 40–42** — Skena 41 thotë se Gishtoja del nga oda me një monedhë, por 42 supozon se ka marrë thesët e pasurisë. Mbetet konflikt skene dhe logjike; nuk u shpik mënyra e marrjes së thasëve. Kërkohet vendim i redaksisë dhe krahasim me ilustrimet.
2. **Ora/Zana 44–46** — Kalimi në tekst midis dy rrëfimeve tani është i qartë, por ilustrimet e shtypura mund të mbajnë tekstin para korrekturës; kërkohet kontroll grafik. Origjina folklorike e emrit Ora dhe varianteve duhen verifikuar nëse libri i paraqet si të dokumentuara.
3. **Ilustrimet me tekst:** ndryshimet e tekstit të leximit nuk ndryshojnë shkrimin brenda WebP. Nevojitet harmonizim para botimit, pa rigjenerim automatik të figurave të miratuara.
4. **Hartat 168–171:** qytetet, numrat e vjetër dhe kufijtë e pasigurt historikisht mbeten çështje grafike të hapura.
5. **Përkthimet/TTS:** redaktimi nga folës amtarë dhe testimi i zërave në telefon mbeten të pakryer.

**Rezultati:** 20 ndryshime të dokumentuara, nga të cilat 12 shqip dhe 8 në gjuhët e huaja. 173/173 WebP të miratuara identike me V73. **Nuk është gati për botim.**
