// V78 - Source-grounded schematic maps (168-171), historical borders not asserted; city labels removed. V77 typo preserved. Previously corrected in image 080; new version bypasses stale caches for updated asset and previously changed maps. Verified continuity and grammar corrections in active reading text with legacy V48 source preserved; cache migration across V68–V70.
// Offline images require browser CacheStorage quota (~75 MB). Failed downloads are resumable.
const CACHE_NAME='qiri-v79-histori-android-integruar';
const PREVIOUS_CACHES=['qiri-v78-cited-schematic-historical-maps','qiri-v77-typo-89-and-maps','qiri-v76-map-footer-clean','qiri-v75-continuity-qa','qiri-v74-continuity-qa','qiri-v73-continuity-qa','qiri-v72-continuity-qa','qiri-v71-errata-map-qa','qiri-v70-map-i18n','qiri-v69-map-qa','qiri-v68-complete-offline'];
const CORE=["./imazhe/080.webp","./imazhe/159.webp","./imazhe/160.webp","./imazhe/161.webp","./imazhe/162.webp","./","./index.html","./kopertina.webp","./manifest.webmanifest","./icons/icon-192.png","./icons/icon-512.png","./manifest.json","./master_leximi_sq_v48.json","./master_leximi_sq_v79_leximi.json","./perkhime_v79_draft.json"];
const IMAGES=["./imazhe/000.webp","./imazhe/001.webp","./imazhe/002.webp","./imazhe/003.webp","./imazhe/004.webp","./imazhe/005.webp","./imazhe/006.webp","./imazhe/007.webp","./imazhe/008.webp","./imazhe/009.webp","./imazhe/010.webp","./imazhe/011.webp","./imazhe/012.webp","./imazhe/013.webp","./imazhe/014.webp","./imazhe/015.webp","./imazhe/016.webp","./imazhe/017.webp","./imazhe/018.webp","./imazhe/019.webp","./imazhe/020.webp","./imazhe/021.webp","./imazhe/022.webp","./imazhe/023.webp","./imazhe/024.webp","./imazhe/025.webp","./imazhe/026.webp","./imazhe/027.webp","./imazhe/028.webp","./imazhe/029.webp","./imazhe/030.webp","./imazhe/031.webp","./imazhe/032.webp","./imazhe/033.webp","./imazhe/034.webp","./imazhe/035.webp","./imazhe/036.webp","./imazhe/037.webp","./imazhe/038.webp","./imazhe/039.webp","./imazhe/040.webp","./imazhe/041.webp","./imazhe/042.webp","./imazhe/043.webp","./imazhe/044.webp","./imazhe/045.webp","./imazhe/046.webp","./imazhe/047.webp","./imazhe/048.webp","./imazhe/049.webp","./imazhe/050.webp","./imazhe/051.webp","./imazhe/052.webp","./imazhe/053.webp","./imazhe/054.webp","./imazhe/055.webp","./imazhe/056.webp","./imazhe/057.webp","./imazhe/058.webp","./imazhe/059.webp","./imazhe/060.webp","./imazhe/061.webp","./imazhe/062.webp","./imazhe/063.webp","./imazhe/064.webp","./imazhe/065.webp","./imazhe/066.webp","./imazhe/067.webp","./imazhe/068.webp","./imazhe/069.webp","./imazhe/070.webp","./imazhe/071.webp","./imazhe/072.webp","./imazhe/073.webp","./imazhe/074.webp","./imazhe/075.webp","./imazhe/076.webp","./imazhe/077.webp","./imazhe/078.webp","./imazhe/079.webp","./imazhe/080.webp","./imazhe/081.webp","./imazhe/082.webp","./imazhe/083.webp","./imazhe/084.webp","./imazhe/085.webp","./imazhe/086.webp","./imazhe/087.webp","./imazhe/088.webp","./imazhe/089.webp","./imazhe/090.webp","./imazhe/091.webp","./imazhe/092.webp","./imazhe/093.webp","./imazhe/094.webp","./imazhe/095.webp","./imazhe/096.webp","./imazhe/097.webp","./imazhe/098.webp","./imazhe/099.webp","./imazhe/100.webp","./imazhe/101.webp","./imazhe/102.webp","./imazhe/103.webp","./imazhe/104.webp","./imazhe/105.webp","./imazhe/106.webp","./imazhe/107.webp","./imazhe/108.webp","./imazhe/109.webp","./imazhe/110.webp","./imazhe/111.webp","./imazhe/112.webp","./imazhe/113.webp","./imazhe/114.webp","./imazhe/115.webp","./imazhe/116.webp","./imazhe/117.webp","./imazhe/118.webp","./imazhe/119.webp","./imazhe/120.webp","./imazhe/121.webp","./imazhe/122.webp","./imazhe/123.webp","./imazhe/124.webp","./imazhe/125.webp","./imazhe/126.webp","./imazhe/127.webp","./imazhe/128.webp","./imazhe/129.webp","./imazhe/130.webp","./imazhe/131.webp","./imazhe/132.webp","./imazhe/133.webp","./imazhe/134.webp","./imazhe/135.webp","./imazhe/136.webp","./imazhe/137.webp","./imazhe/138.webp","./imazhe/139.webp","./imazhe/140.webp","./imazhe/141.webp","./imazhe/142.webp","./imazhe/143.webp","./imazhe/144.webp","./imazhe/145.webp","./imazhe/146.webp","./imazhe/147.webp","./imazhe/148.webp","./imazhe/149.webp","./imazhe/150.webp","./imazhe/151.webp","./imazhe/152.webp","./imazhe/153.webp","./imazhe/154.webp","./imazhe/155.webp","./imazhe/156.webp","./imazhe/157.webp","./imazhe/158.webp","./imazhe/159.webp","./imazhe/160.webp","./imazhe/161.webp","./imazhe/162.webp","./imazhe/163.webp","./imazhe/164.webp","./imazhe/165.webp","./imazhe/166.webp","./imazhe/167.webp","./imazhe/168.webp","./imazhe/169.webp","./imazhe/170.webp","./imazhe/171.webp","./imazhe/172.webp"];
const UPDATED_IMAGES=new Set(["./imazhe/080.webp","./imazhe/159.webp","./imazhe/160.webp","./imazhe/161.webp","./imazhe/162.webp"]);
let job=null;
const observers=new Set();
const post=(msg)=>{for(const p of observers){try{p.postMessage(msg);}catch(_){observers.delete(p);}}};
self.addEventListener('install',event=>{
 event.waitUntil(caches.open(CACHE_NAME).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
 event.waitUntil((async()=>{
  const names=await caches.keys();
  await Promise.all(names.filter(n=>n.startsWith('qiri-v')&&n!==CACHE_NAME&&!PREVIOUS_CACHES.includes(n)).map(n=>caches.delete(n)));
  await self.clients.claim();
 })());
});
async function getPreviousCaches(){
 const names=await caches.keys();
 return Promise.all(PREVIOUS_CACHES.filter(n=>names.includes(n)).map(n=>caches.open(n)));
}
async function findCached(url,cache,oldCaches){
 const hit=await cache.match(url);if(hit)return hit;
 if(UPDATED_IMAGES.has(url)){
      const names=await caches.keys();
      if(!names.includes('qiri-v78-cited-schematic-historical-maps'))return null;
      const previous=await caches.open('qiri-v78-cited-schematic-historical-maps');
      return await previous.match(url)||null;
    }
 for(const old of oldCaches){const prev=await old.match(url);if(prev)return prev;}
 return null;
}
async function countCached(cache,oldCaches=null){
 const olds=oldCaches||await getPreviousCaches();let count=0;
 for(const url of IMAGES)if(await findCached(url,cache,olds))count++;
 return count;
}
async function downloadAll(){
 const cache=await caches.open(CACHE_NAME),olds=await getPreviousCaches();
 let cached=await countCached(cache,olds),next=0,firstError=null;
 post({type:'progress',cached,total:IMAGES.length});
 if(cached===IMAGES.length){post({type:'complete',cached,total:IMAGES.length});return;}
 const work=async()=>{
   while(next<IMAGES.length){
    const url=IMAGES[next++];
    if(await findCached(url,cache,olds))continue;
    try{
      await cache.add(url);
      cached++;
      post({type:'progress',cached,total:IMAGES.length});
    }catch(error){if(!firstError)firstError=String(error&&error.message||error);}
   }
 };
 await Promise.all([work(),work(),work()]);
 cached=await countCached(cache,olds);
 if(cached===IMAGES.length)post({type:'complete',cached,total:IMAGES.length});
 else post({type:'error',cached,total:IMAGES.length,message:'Shkarkimi nuk u përfundua. Kontrollo lidhjen dhe hapësirën; përdor Riprovo. '+(firstError||'')});
}
self.addEventListener('message',event=>{
 const port=event.ports&&event.ports[0];if(!port)return;
 const act=event.data&&event.data.action;
 if(act==='CACHE_STATUS'){
  event.waitUntil(caches.open(CACHE_NAME).then(async cache=>{
   const cached=await countCached(cache);
   port.postMessage({type:'status',cached,total:IMAGES.length});
  }).catch(e=>port.postMessage({type:'error',cached:0,total:IMAGES.length,message:String(e)})));
 }else if(act==='CACHE_ALL'){
  observers.add(port);
  if(!job){job=downloadAll().catch(e=>post({type:'error',cached:0,total:IMAGES.length,message:String(e)})).finally(()=>{observers.clear();job=null;});}
  event.waitUntil(job);
 }
});
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 const url=new URL(event.request.url);if(url.origin!==self.location.origin)return;
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE_NAME);
  const found=await cache.match(event.request);if(found)return found;
  if(url.pathname.endsWith('.webp')){
    const updated=/\/imazhe\/(080|159|160|161|162)\.webp$/.test(url.pathname);
    if(updated){
      const names=await caches.keys();
      if(names.includes('qiri-v78-cited-schematic-historical-maps')){
        const v78=await caches.open('qiri-v78-cited-schematic-historical-maps');
        const hit=await v78.match(event.request);if(hit)return hit;
      }
    }else{
      for(const old of await getPreviousCaches()){const hit=await old.match(event.request);if(hit)return hit;}
    }
  }
  try{
   const res=await fetch(event.request);
   if(res.ok){const copy=res.clone();event.waitUntil(cache.put(event.request,copy).catch(()=>{}));}
   return res;
  }catch(err){return new Response('Materiali nuk u ruajt për lexim offline.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});}
 })());
});
