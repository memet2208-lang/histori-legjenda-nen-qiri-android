# V72 — Audit i vazhdimësisë, korrigjimet dhe punët e hapura

**Burimi:** V71; V48 dhe 173 ilustrimet origjinale ruhen identike. **APK-ja shtyhet për në fund.**

## Korrigjime të zbatuara në tekstin aktiv

- **Dyfaqëshja 30, Halili dhe Tanusha (të dyja anët):** «i biri/djali i Mujit» u korrigjua në «vëllai më i vogël/vëllai i Mujit», pasi në këngët e kreshnikëve Muji dhe Halili janë vëllezër. Përkthimet IT, EN, DE, FR, ES u harmonizuan në të dy anët. Burime: https://www.iett.al/the-epic-of-the-kreshniks/?lang=en dhe https://albmyth.com/en/e/halili.
- **Dyfaqëshja 40, Gishtoja:** «të këqinj» u ndreq në «të këqij» dhe «aritë» në «ari/arin/arit» sipas rasës. Përkthimet nuk kërkonin ndryshim kuptimor.
- **Dyfaqëshja 89:** korrigjimi i mëparshëm «mëhoi → mësoi» ruhet në tekstin e leximit.

## Çështje që nuk u ndryshuan pa miratim redaksional

1. **Dyfaqëshet 33–35 (Halili dhe Tanusha):** pas kthimit dhe bashkimit në 33, dyfaqëshja 34 tregon largimin pas dasmës, kurse 35 e ritregon kthimin *pas shpëtimit*, që tashmë ka ndodhur në 33. Kërkon riorganizim narrativ, jo vetëm korrekturë fjalësh; tekstet e miratuara dhe ilustrimet nuk u rishkruan.
2. **Dyfaqëshet 81–82 (Syri i Kaltër dhe Lubia):** 81 përgatit përballjen dhe planin; 82 hapet «Pas zhdukjes së Lubisë» pa skenën që lidh ngjarjet. Kërkon vendim për lidhjen narrative; nuk është sajuar skenë.
3. **Dyfaqëshja 83 dhe 172:** të dyja përshkruajnë kthimin e dritave dhe fikjen e qiririt. Dyfaqëshja 83 funksionon si mbyllje e parakohshme para pjesës «Jeta e përditshme»; duhen rishikuar si pjesë e strukturës së librit.
4. **Dyfaqëshja 40, Gishtoja:** rrëfimi e paraqet Gishtojën duke ndihmuar vjedhësit, ndërsa dyfaqëshja 38 e prezanton si shpëtimtar të fshatit. Mund të jetë element i variantit folklorik; kërkohet vendim redaksional për shpjegim, jo fshirje mekanike.
5. **Hartat 168–171:** qytetet dhe numrat e vjetër 92–99 janë të shtypur në figurë; duhet korrigjim grafik pikë për pikë në origjinal (jo hartë e re e krijuar me hamendësime). Kufijtë historikë mbeten për ekspertizë.
6. **Ilustrimet e dyfaqësheve 30, 40 dhe 89:** teksti i shtypur mund të mbetet në kundërshtim me tekstin aktiv. Nuk u zëvendësua asnjë imazh i miratuar; për secilën ruhet arkivi.

## Gjendja e botimit

Të 173 dyfaqëshet kanë draft në gjashtë gjuhë; janë kryer kalimet me AI, por **nuk ka verifikim të plotë nga redaktorë amtarë**, kontroll kartografik përfundimtar, test offline në HTTPS apo provë në telefon. **Gati për botim: JO.**
