HISTORI DHE LEGJENDA NËN QIRI — V79 (PROJEKT ANDROID PËR TESTIM)

Baza: V78, 173 dyfaqëshe, 6 gjuhë, 4 harta të reja dhe burimet e tyre direkte.
Ndryshim historik i V79: në dyfaqëshen 2, pengmarrja e Skënderbeut është vendosur PARA betejës së Nishit (1443).
Të gjitha figurat janë të paketuara lokalisht në app/src/main/assets/www/imazhe/.

PËR TË NDËRTUAR APK: Nxirr ZIP në një depo të re GitHub si skedarë të zakonshëm dhe përdor Actions → Ndërto APK V79 → Run workflow.
Gjej artifact NEN-QIRI-V79-APK-DEBUG-TEST dhe shkarko APK-në për instalim testues.
Në këtë mjedis nuk ka Gradle/Android SDK: APK-ja nuk është kompiluar ende.
Zërat varen nga TTS-ja e instaluar në telefon. Te paneli 🔊 përdor "Kontrollo zërat" dhe "Provo shqiptimin".
Kontrolli historik e gjuhësor nga profesionistë amtarë mbetet i papërfunduar.
