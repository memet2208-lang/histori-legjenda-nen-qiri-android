package al.qiri.reader;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Native, foreground Android TTS: tries network voices, uses installed fallback, works screen-off. */
public final class NarrationService extends Service {
  public static final String STATUS_EVENT="al.qiri.reader.NARRATION_STATUS";
  public static final String ACTION_PLAY="qiri.PLAY",ACTION_PAUSE="qiri.PAUSE",ACTION_STOP="qiri.STOP",
      ACTION_PAGE="qiri.PAGE",ACTION_LANGUAGE="qiri.LANGUAGE",ACTION_SPEED="qiri.SPEED",
      ACTION_MODE="qiri.MODE",ACTION_NETWORK="qiri.NETWORK",
      ACTION_RESUME="qiri.RESUME",ACTION_PAUSE_ONLY="qiri.PAUSE_ONLY",
      ACTION_QUERY_STATUS="qiri.QUERY_STATUS",ACTION_NEXT="qiri.NEXT",ACTION_PREVIOUS="qiri.PREVIOUS";
  private static final String CHANNEL="qiri_narration";
  private static final int NOTIFICATION_ID=874;
  private NotificationManager notificationManager;
  private MediaSession mediaSession;
  private boolean foregroundStarted=false;
  private String currentAnnouncement="";
  private final Handler handler=new Handler(Looper.getMainLooper());
  private TextToSpeech tts;
  private final ExecutorService cloudJobs=Executors.newSingleThreadExecutor();
  private Future<?> cloudPending;
  private MediaPlayer cloudPlayer;
  private File cloudAudio;
  private boolean cloudSegment=false,utteranceStarted=false;
  private boolean publicReady=false;
  private List<String> publicTracks=new ArrayList<>();
  private int publicTrackIndex=0;
  private Runnable speechWatchdog;
  private JSONArray pages;
  private PowerManager.WakeLock wakeLock;
  private AudioManager audioManager;
  private AudioFocusRequest focusRequest;
  private boolean ready=false,playing=false,paused=false,onlinePreferred=true,networkVoice=false;
  private int page=0,mode=0,part=0,epoch=0,voiceAlternation=0;
  private float speed=1f;
  private String language="sq", voiceInfo="";
  private final List<Segment> segments=new ArrayList<>();
  private List<Voice> possibleVoices=new ArrayList<>();
  private boolean networkFallbackUsed=false;

  private static final class Segment {
    String text;boolean dialogue;
    Segment(String text,boolean dialogue){this.text=text;this.dialogue=dialogue;}
  }
  @Override public void onCreate(){
    super.onCreate();
    try(InputStream in=getAssets().open("book_texts.json")){
      ByteArrayOutputStream o=new ByteArrayOutputStream(); byte[] b=new byte[16384];int n;
      while((n=in.read(b))>0)o.write(b,0,n);
      pages=new JSONObject(o.toString("UTF-8")).getJSONArray("spreads");
    }catch(Exception e){Log.e("QiriAudio","Cannot load book",e);}
    audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
    PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
    wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Qiri::NativeSpeech");
    wakeLock.setReferenceCounted(false);
    makeChannel();
    createMediaSession();
    tts=new TextToSpeech(getApplicationContext(),status->handler.post(()->{
      ready=status==TextToSpeech.SUCCESS;
      if(!ready){
        // Prerecorded online audio needs no Android TTS engine.
        if(playing && !paused && segments.isEmpty())beginPage();
        return;
      }
      tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
        @Override public void onStart(String id) {handler.post(()->{
          if(current(id)){utteranceStarted=true; cancelSpeechWatchdog();report("playing",voiceInfo+" · po dëgjohet");}
        });}
        @Override public void onDone(String id){handler.post(()->completed(id));}
        @Override public void onError(String id){handler.post(()->failed(id,"Gabim i motorit TTS"));}
        @Override public void onError(String id,int code){handler.post(()->failed(id,"Gabim TTS: "+code));}
      });
      // Do not restart the cloud request that may already be synthesizing while
      // TextToSpeech was still initializing.
      if(playing&&!paused && segments.isEmpty())beginPage();
      else if(ready && playing && !paused && cloudPlayer==null && cloudPending==null)pickVoices();
    }));
  }
  @Override public int onStartCommand(Intent request,int flags,int startId){
    if(request==null)return START_NOT_STICKY;
    String action=request.getAction();
    int requestedPage=Math.max(0,Math.min(request.getIntExtra("page",page),218));
    String requestedLanguage=request.getStringExtra("lang");
    if(requestedLanguage==null)requestedLanguage=language;
    page=requestedPage;language=requestedLanguage;
    mode=request.getIntExtra("mode",mode);speed=request.getFloatExtra("speed",speed);
    onlinePreferred=request.getBooleanExtra("network",onlinePreferred);
    if(ACTION_PLAY.equals(action)){
      playing=true;paused=false;networkFallbackUsed=false;
      enterForeground();holdWakeLock();requestAudioFocus();
      beginPage();
      else report("loading","Duke nisur motorin e zërit…");
    } else if(ACTION_STOP.equals(action)){
      quit();
    } else if(ACTION_PAUSE.equals(action)){
      if(playing){ if(paused)resumeNarration();else pauseNarration(); }
    } else if(ACTION_PAUSE_ONLY.equals(action)){
      if(playing&&!paused)pauseNarration();
    } else if(ACTION_QUERY_STATUS.equals(action)){
      report(playing?(paused?"paused":"playing"):"stopped",
        playing?(paused?"Në pauzë":"Po lexohet dyfaqëshja "+(page+1)):"Leximi nuk është aktiv");
    } else if(ACTION_RESUME.equals(action)){
      if(playing){ if(paused)resumeNarration(); }
      // When the playback service has stopped, only the app itself starts a new
      // reading session with language and page. Do not restart at page 1 here.
    } else if(ACTION_NEXT.equals(action)||ACTION_PREVIOUS.equals(action)){
      if(playing){
        int nextPage=Math.max(0,Math.min(page+(ACTION_NEXT.equals(action)?1:-1),218));
        if(nextPage!=page){ page=nextPage; epoch++;
          if(tts!=null)tts.stop();stopCloud();cancelSpeechWatchdog();
          beginPage();
          if(paused)report("paused","Dyfaqëshja "+(page+1)+" — në pauzë");
        }
      }
    } else if(ACTION_PAGE.equals(action)||ACTION_LANGUAGE.equals(action)){
      if(playing){epoch++;if(tts!=null)tts.stop();stopCloud();cancelSpeechWatchdog();
        beginPage();
        if(paused)report("paused","Dyfaqëshja "+(page+1)+" — në pauzë");
      }
    } else if(ACTION_MODE.equals(action)||ACTION_SPEED.equals(action)||ACTION_NETWORK.equals(action)){
      if(playing){epoch++;if(tts!=null)tts.stop();
        stopCloud();cancelSpeechWatchdog();beginPage();}
    }
    return playing?START_STICKY:START_NOT_STICKY;
  }
  private void pauseNarration(){
    paused=true;
    if(cloudPlayer==null&&cloudPending==null)epoch++;
    if(tts!=null)tts.stop();
    cancelSpeechWatchdog();
    if(cloudPlayer!=null)try{if(cloudPlayer.isPlaying())cloudPlayer.pause();}catch(Exception ignored){}
    releaseWakeLock();report("paused","Leximi në pauzë");
  }
  private void resumeNarration(){
    paused=false;holdWakeLock();requestAudioFocus();
    if(cloudPlayer!=null){
      if(publicReady){try{cloudPlayer.start();report("playing","🌐 Zë publik (rifillim)");}
        catch(Exception e){playPublicTrack();}}
      else report("loading","🌐 Audio po ngarkohet…");
    } else if(!publicTracks.isEmpty())playPublicTrack();
    else if(ready)utter();
    else beginPage();
  }
  private void beginPage(){
    if(pages==null){abort("Teksti i librit nuk u ngarkua");return;}
    epoch++;part=0;voiceAlternation=0;networkFallbackUsed=false;segments.clear();
    stopCloud();cancelSpeechWatchdog();
    if(playing&&!paused){releaseWakeLock();holdWakeLock();}
    try{
      JSONObject row=pages.getJSONObject(page).optJSONObject(language);
      if(row==null){abort("Mungon teksti për gjuhën "+language);return;}
      appendSegments(row.optString("left"));appendSegments(row.optString("right"));
      if(segments.isEmpty()){abort("Faqja nuk ka tekst për të lexuar");return;}
      if(ready)pickVoices(); else possibleVoices.clear();
      if(onlinePreferred){fetchPublicPage();return;}
      if(possibleVoices.isEmpty()){
        abort("Nuk ka zë offline "+tag(language)+". Aktivizo motorin Android TTS.");return;
      }
      utter();
    }catch(Exception e){abort("Gabim gjatë leximit të tekstit: "+e.getMessage());}
  }
  private void appendSegments(String value){
    String[] lines=value.replace("\r","").split("\n+");
    for(String raw:lines){
      // Keep the printed book untouched, but turn decorative ALL-CAPS headings
      // into normal spoken words so the engine doesn't spell each letter.
      String t=SpeechTextNormalizer.forSpeech(raw,locale());
      if(t.isEmpty())continue;
      boolean dialogue=t.startsWith("—")||t.startsWith("–")||t.startsWith("-");
      // Chunk for the Android TTS utterance limit. Preserve dialogue boundaries and text.
      String[] words=t.split("\\s+");StringBuilder chunk=new StringBuilder();
      for(String word:words){
        if(chunk.length()>0&&chunk.length()+word.length()+1>270){segments.add(new Segment(chunk.toString(),dialogue));chunk.setLength(0);}
        if(chunk.length()>0)chunk.append(' ');chunk.append(word);
      }
      if(chunk.length()>0)segments.add(new Segment(chunk.toString(),dialogue));
    }
  }
  private String tag(String lang){
    switch(lang){case "it":return "it-IT";case "en":return "en-GB";case "de":return "de-DE";
      case "fr":return "fr-FR";case "es":return "es-ES";default:return "sq-AL";}
  }
  private Locale locale(){return Locale.forLanguageTag(tag(language));}
  private int quality(Voice v){
    int score=0;
    if(v.isNetworkConnectionRequired())score+=onlinePreferred?1000:0;
    else if(!onlinePreferred)score+=600;
    if(v.getLocale().toLanguageTag().equalsIgnoreCase(tag(language)))score+=100;
    score+=v.getQuality()*10;
    String n=v.getName().toLowerCase(Locale.ROOT);
    if(n.contains("neural")||n.contains("natural")||n.contains("enhanced"))score+=40;
    return score;
  }
  private void pickVoices(){
    possibleVoices.clear();
    Locale l=locale();
    try{
      Set<Voice> vs=tts.getVoices();
      if(vs!=null)for(Voice v:vs){
        if(v.getLocale()==null || !l.getLanguage().equals(v.getLocale().getLanguage()))continue;
        if(v.getFeatures()!=null && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED))continue;
        possibleVoices.add(v);
      }
      Collections.sort(possibleVoices,(a,b)->Integer.compare(quality(b),quality(a)));
    }catch(Exception e){Log.w("QiriAudio","Cannot enumerate installed voices",e);}
    if(possibleVoices.isEmpty()){
      // Android TTS setLanguage fallback only when engine declares THIS language available.
      int can=tts.isLanguageAvailable(l);
      if(can>=TextToSpeech.LANG_AVAILABLE){
        tts.setLanguage(l);Voice basic=tts.getVoice();
        if(basic!=null && basic.getLocale()!=null && l.getLanguage().equals(basic.getLocale().getLanguage()))possibleVoices.add(basic);
      }
    }
  }
  private void utter(){
    // Narration using an available Android voice while public recordings are missing.
    if(!playing||paused||!ready)return;
    if(part>=segments.size()){
      if(page+1>=219){playing=false;releaseWakeLock();releaseFocus();report("finished","Fundi i librit");finishForeground();stopSelf();return;}
      page++; beginPage(); return;
    }
    if(!ready||possibleVoices.isEmpty()){
      abort("Nuk gjendet zë për "+tag(language)+". Instalo zërin e gjuhës në Speech Services by Google.");return;
    }
    Segment segment=segments.get(part);
    int voiceIndex=0;
    if(mode==2 && possibleVoices.size()>1)voiceIndex=1;
    if(mode==0 && possibleVoices.size()>1 && segment.dialogue)voiceIndex=voiceAlternation++%2;
    Voice voice=possibleVoices.get(voiceIndex);
    if(tts.setVoice(voice)==TextToSpeech.ERROR){
      // Try another matching engine voice, not the same failed one.
      possibleVoices.remove(voice);
      if(!possibleVoices.isEmpty()){epoch++;utter();}
      else abort("Zëri "+tag(language)+" nuk mund të aktivizohet. Instalo gjuhën Android TTS.");
      return;
    }
    networkVoice=voice.isNetworkConnectionRequired();voiceInfo=(networkVoice?"🌐 Zë online":"Zë i pajisjes")+" · "+tag(language);
    tts.setSpeechRate(Math.max(.65f,Math.min(1.4f,speed)));
    tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
    String utteranceId=epoch+"-"+part;
    report("loading","Po përgatitet "+voiceInfo);
    Bundle params=new Bundle();
    if(networkVoice){
      params.putString(TextToSpeech.Engine.KEY_FEATURE_NETWORK_TIMEOUT_MS,"16000");
      params.putString(TextToSpeech.Engine.KEY_FEATURE_NETWORK_RETRIES_COUNT,"1");
    }
    utteranceStarted=false;
    int result=tts.speak(segment.text,TextToSpeech.QUEUE_FLUSH,params,utteranceId);
    if(result==TextToSpeech.ERROR)failed(utteranceId,"Motori refuzoi zërin");
    else {
      // Some network TTS engines return SUCCESS yet never begin audio.
      cancelSpeechWatchdog();
      speechWatchdog=()->{
        if(current(utteranceId)&&playing&&!paused&&!utteranceStarted)
          failed(utteranceId,"Motori i zërit nuk filloi. Provo zëra të tjerë te cilësimet e telefonit");
      };
      handler.postDelayed(speechWatchdog,networkVoice?17000:8500);
    }
  }
  private boolean current(String id){return id!=null&&id.equals(epoch+"-"+part);}
  private void completed(String id){if(!current(id)||!playing||paused)return;
    cancelSpeechWatchdog();part++;utter();}
  private void failed(String id,String message){
    if(!current(id)||!playing)return;
    // Network engines can fail when unavailable. Retry once using an installed local voice.
    if(networkVoice&&!networkFallbackUsed){
      networkFallbackUsed=true;
      List<Voice> locals=new ArrayList<>();for(Voice v:possibleVoices)if(!v.isNetworkConnectionRequired())locals.add(v);
      if(!locals.isEmpty()){ possibleVoices.clear();possibleVoices.addAll(locals);
        epoch++;report("playing","Lidhja e zërit online dështoi; përdoret zëri lokal "+tag(language));utter();return;}
    }
    abort(message+". Kontrollo internetin ose zërat e instaluar për "+tag(language));
  }
  private void cancelSpeechWatchdog(){if(speechWatchdog!=null)handler.removeCallbacks(speechWatchdog);speechWatchdog=null;}
  /** Cancels both public manifest fetch and network playback when the page changes. */
  private void stopCloud(){
    if(cloudPending!=null){cloudPending.cancel(true);cloudPending=null;}
    if(cloudPlayer!=null){try{cloudPlayer.reset();cloudPlayer.release();}catch(Exception ignored){}cloudPlayer=null;}
    if(cloudAudio!=null){cloudAudio.delete();cloudAudio=null;}
    cloudSegment=false;publicReady=false;
    publicTracks.clear();publicTrackIndex=0;
  }
  private void fetchPublicPage(){
    final int pageNow=page,epochNow=epoch;
    final String langNow=language;
    report("loading","🌐 Kërkohet audio publike për dyfaqëshen "+(page+1)+"…");
    cloudPending=cloudJobs.submit(()->{
      List<String> urls=new ArrayList<>();
      try{urls=PublicAudio.forSpread(getApplicationContext(),pageNow,langNow);}
      catch(Exception e){Log.w("QiriAudio","Catalog unavailable",e);}
      final List<String> result=urls;
      handler.post(()->{
        if(!playing||pageNow!=page||epochNow!=epoch)return;
        cloudPending=null;
        if(!result.isEmpty()){
          publicTracks=new ArrayList<>(result);publicTrackIndex=0;
          if(!paused)playPublicTrack();else report("paused","Audio online gati për këtë dyfaqëshe");
        }else {
          report("loading","Audio online s'është publikuar ende. Provohet TTS lokal…");
          if(ready&&!possibleVoices.isEmpty()){if(!paused)utter();}
          else abort("Audio online për dyfaqëshen "+(page+1)+" ("+langNow+") nuk është publikuar ende dhe mungon zëri lokal.");
        }
      });
    });
  }
  private void playPublicTrack(){
    if(!playing||paused)return;
    if(publicTrackIndex>=publicTracks.size()){
      stopCloud();
      if(page+1>=219){playing=false;releaseWakeLock();releaseFocus();report("finished","Fundi i librit");finishForeground();stopSelf();}
      else{page++;beginPage();}
      return;
    }
    if(cloudPlayer!=null){try{cloudPlayer.reset();cloudPlayer.release();}catch(Exception ignored){}cloudPlayer=null;}
    publicReady=false;
    final int expectedEpoch=epoch,expectedTrack=publicTrackIndex;
    final String url=publicTracks.get(publicTrackIndex);
    report("loading","🌐 Audio publike · "+tag(language)+" · pjesa "+(expectedTrack+1)+"/"+publicTracks.size());
    try {
      MediaPlayer player=new MediaPlayer();cloudPlayer=player;
      player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
      player.setOnPreparedListener(mp->{
        if(epoch!=expectedEpoch||cloudPlayer!=mp||publicTrackIndex!=expectedTrack)return;
        publicReady=true;
        if(!paused&&playing){mp.start();report("playing","🌐 Zë natyral publik · "+tag(language));}
      });
      player.setOnCompletionListener(mp->{
        if(epoch!=expectedEpoch||publicTrackIndex!=expectedTrack)return;
        publicTrackIndex++;playPublicTrack();
      });
      player.setOnErrorListener((mp,what,extra)->{
        if(epoch==expectedEpoch)abort("Gabim në transmetimin online ("+what+"). Kontrollo lidhjen.");
        return true;
      });
      player.setDataSource(url);
      player.prepareAsync();
    }catch(Exception e){abort("Gabim në hapjen e audios online: "+e.getMessage());}
  }
  private void holdWakeLock(){if(wakeLock!=null&&!wakeLock.isHeld())wakeLock.acquire(4*60*60*1000L);}
  private void releaseWakeLock(){if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();}
  private void requestAudioFocus(){
    if(audioManager==null)return;
    try{
      focusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
          .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
          .setOnAudioFocusChangeListener(change->{if(change==AudioManager.AUDIOFOCUS_LOSS)handler.post(()->{if(playing&&!paused){paused=true;if(cloudPlayer==null&&cloudPending==null)epoch++;if(tts!=null)tts.stop();
          if(cloudPlayer!=null)try{cloudPlayer.pause();}catch(Exception ignored){}
          releaseWakeLock();report("paused","Një aplikacion tjetër përdor zërin");}});}).build();
      audioManager.requestAudioFocus(focusRequest);
    }catch(Exception ignored){}
  }
  private void releaseFocus(){try{if(focusRequest!=null&&audioManager!=null)audioManager.abandonAudioFocusRequest(focusRequest);}catch(Exception ignored){}}
  private void report(String status,String msg){
    Intent i=new Intent(STATUS_EVENT).setPackage(getPackageName());
    i.putExtra("status",status);i.putExtra("page",page);
    i.putExtra("lang",language);i.putExtra("message",msg);
    sendBroadcast(i);
    currentAnnouncement=msg==null?"":msg;
    refreshTransportNotification();
  }
  private void makeChannel(){
    notificationManager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    NotificationChannel channel=new NotificationChannel(CHANNEL,
       "Leximi i librit me zë",NotificationManager.IMPORTANCE_LOW);
    channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
    channel.enableVibration(false);
    notificationManager.createNotificationChannel(channel);
  }
  /** Android system media player controls: visible in shade and on lock screen,
   *  subject to the user's lock-screen privacy and notification settings. */
  private void createMediaSession(){
    mediaSession=new MediaSession(this,"QiriBookNarration");
    mediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS
      |MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
    mediaSession.setCallback(new MediaSession.Callback(){
      @Override public void onPlay(){handler.post(()->sendTransport(ACTION_RESUME));}
      @Override public void onPause(){handler.post(()->sendTransport(ACTION_PAUSE_ONLY));}
      @Override public void onSkipToNext(){handler.post(()->sendTransport(ACTION_NEXT));}
      @Override public void onSkipToPrevious(){handler.post(()->sendTransport(ACTION_PREVIOUS));}
      @Override public void onStop(){handler.post(()->sendTransport(ACTION_STOP));}
    });
    mediaSession.setActive(false);
  }
  private void sendTransport(String action){
    // All intents are explicit and targeted to our own private service.
    try{startService(new Intent(this,NarrationService.class).setAction(action));}
    catch(Exception e){Log.w("QiriAudio","Media command failed: "+action,e);}
  }
  private PendingIntent transportIntent(String action,int requestCode){
    return PendingIntent.getService(this,requestCode,
      new Intent(this,NarrationService.class).setAction(action),
      PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  }
  private void updateMediaSession(){
    if(mediaSession==null)return;
    mediaSession.setActive(playing);
    final int state=!playing?PlaybackState.STATE_STOPPED:
      (paused?PlaybackState.STATE_PAUSED:PlaybackState.STATE_PLAYING);
    long actions=PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE
      |PlaybackState.ACTION_PLAY_PAUSE|PlaybackState.ACTION_SKIP_TO_NEXT
      |PlaybackState.ACTION_SKIP_TO_PREVIOUS|PlaybackState.ACTION_STOP;
    mediaSession.setPlaybackState(new PlaybackState.Builder()
      .setActions(actions)
      .setState(state,PlaybackState.PLAYBACK_POSITION_UNKNOWN,
        state==PlaybackState.STATE_PLAYING?1f:0f).build());
    mediaSession.setMetadata(new MediaMetadata.Builder()
      .putString(MediaMetadata.METADATA_KEY_TITLE,"Dyfaqëshja "+(page+1)+" / 219")
      .putString(MediaMetadata.METADATA_KEY_ARTIST,"Histori dhe Legjenda nën Qiri")
      .putString(MediaMetadata.METADATA_KEY_ALBUM,"Leximi me zë · "+language.toUpperCase(Locale.ROOT))
      .build());
  }
  private Notification mediaNotification(){
    Intent open=new Intent(this,MainActivity.class)
      .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP)
      .putExtra("qiri_media_open",true);
    PendingIntent openIntent=PendingIntent.getActivity(this,0,open,
      PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    String title="Histori dhe Legjenda nën Qiri";
    String subtitle="Dyfaqëshja "+(page+1)+"/219 · "+language.toUpperCase(Locale.ROOT)
      +(paused?" · Pauzë":" · Lexim me zë");
    String toggleAction=paused?ACTION_RESUME:ACTION_PAUSE_ONLY;
    String toggleTitle=paused?"Luaj":"Pauzë";
    int toggleIcon=paused?android.R.drawable.ic_media_play:android.R.drawable.ic_media_pause;
    return new Notification.Builder(this,CHANNEL)
      .setSmallIcon(android.R.drawable.ic_media_play)
      .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher))
      .setContentTitle(title).setContentText(subtitle)
      .setSubText(currentAnnouncement)
      .setContentIntent(openIntent)
      .setOnlyAlertOnce(true)
      .setAutoCancel(false)
      .setOngoing(playing&&!paused)
      .setVisibility(Notification.VISIBILITY_PUBLIC)
      .setCategory(Notification.CATEGORY_TRANSPORT)
      .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous,
        "Para",transportIntent(ACTION_PREVIOUS,201)).build())
      .addAction(new Notification.Action.Builder(toggleIcon,
        toggleTitle,transportIntent(toggleAction,202)).build())
      .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next,
        "Pas",transportIntent(ACTION_NEXT,203)).build())
      .setStyle(new Notification.MediaStyle()
        .setMediaSession(mediaSession.getSessionToken())
        .setShowActionsInCompactView(0,1,2))
      .build();
  }
  private void enterForeground(){
    updateMediaSession();
    Notification n=mediaNotification();
    if(Build.VERSION.SDK_INT>=29)
      startForeground(NOTIFICATION_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    else startForeground(NOTIFICATION_ID,n);
    foregroundStarted=true;
  }
  private void refreshTransportNotification(){
    if(!foregroundStarted||!playing)return;
    updateMediaSession();
    if(notificationManager!=null)notificationManager.notify(NOTIFICATION_ID,mediaNotification());
  }
  private void finishForeground(){
    foregroundStarted=false;
    updateMediaSession();
    if(Build.VERSION.SDK_INT>=24)stopForeground(STOP_FOREGROUND_REMOVE);
    else stopForeground(true);
  }
  private void abort(String message){
    playing=false;paused=false;epoch++;cancelSpeechWatchdog();stopCloud();if(tts!=null)tts.stop();releaseWakeLock();releaseFocus();
    report("error",message);finishForeground();stopSelf();
  }
  private void quit(){
    playing=false;paused=false;epoch++;cancelSpeechWatchdog();stopCloud();if(tts!=null)tts.stop();releaseWakeLock();releaseFocus();
    report("stopped","Leximi u ndal");finishForeground();stopSelf();
  }
  @Override public void onDestroy(){
    playing=false;cancelSpeechWatchdog();stopCloud();cloudJobs.shutdownNow();
    releaseWakeLock();releaseFocus();
    if(mediaSession!=null){mediaSession.setActive(false);mediaSession.release();mediaSession=null;}
    if(tts!=null){tts.stop();tts.shutdown();}
    super.onDestroy();
  }
  @Override public IBinder onBind(Intent intent){return null;}
}
