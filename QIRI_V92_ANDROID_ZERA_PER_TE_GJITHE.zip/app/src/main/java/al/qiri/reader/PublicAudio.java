package al.qiri.reader;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/** Public, prerecorded audiobook segments. Listeners NEVER need any TTS API key.
 *  The catalog is updated remotely, without rebuilding the Android application.
 *  Never use this resolver for arbitrary user-provided URLs. */
final class PublicAudio {
  static final String CATALOG_URL = "https://raw.githubusercontent.com/memet2208-lang/histori-legjenda-nen-qiri-android/main/QIRI_PUBLIC_AUDIO_CATALOG.json";
  private static final String PREF = "qiri_public_audio_catalog";
  private static final long TTL_MS = 15 * 60 * 1000L;
  private static final int MAX_BYTES = 1024 * 1024;
  private PublicAudio() {}

  static List<String> forSpread(Context context, int pageZeroBased, String language) throws Exception {
    SharedPreferences prefs=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
    String raw=prefs.getString("json", "");
    long last=prefs.getLong("updated",0);
    if(raw.isEmpty()||System.currentTimeMillis()-last>TTL_MS){
      HttpURLConnection c=(HttpURLConnection)new URL(CATALOG_URL).openConnection();
      c.setConnectTimeout(5000);c.setReadTimeout(6000);c.setRequestProperty("Accept","application/json");
      try{
        if(c.getResponseCode()==200){
          ByteArrayOutputStream b=new ByteArrayOutputStream();
          try(InputStream in=c.getInputStream()){
            byte[] buf=new byte[8192];int n;
            while((n=in.read(buf))>=0){b.write(buf,0,n);if(b.size()>MAX_BYTES)throw new Exception("Catalog too large");}
          }
          raw=b.toString("UTF-8");
          new JSONObject(raw); // Validate before replacing a previously cached good catalog.
          prefs.edit().putString("json",raw).putLong("updated",System.currentTimeMillis()).apply();
        }
      } catch(Exception e){if(raw.isEmpty())return new ArrayList<>();}
      finally{c.disconnect();}
    }
    ArrayList<String> result=new ArrayList<>();
    if(raw.isEmpty())return result;
    JSONObject root=new JSONObject(raw);
    if(root.optInt("version",0)!=1)return result;
    JSONObject languages=root.optJSONObject("tracks");
    if(languages==null)return result;
    JSONObject pages=languages.optJSONObject(language);
    if(pages==null)return result;
    JSONArray tracks=pages.optJSONArray(Integer.toString(pageZeroBased+1));
    if(tracks==null)return result;
    String base=root.optString("base_url","").replaceAll("/+$","");
    if(!base.startsWith("https://")||base.contains("?")||base.contains("#"))return result;
    for(int i=0;i<tracks.length();i++){
      String filename=tracks.optString(i,"");
      if(filename.isEmpty()||filename.startsWith("/")||filename.contains("..")
         ||!filename.matches("[a-z0-9/_-]+\\.mp3"))return new ArrayList<>();
      result.add(base+"/"+filename);
    }
    return result;
  }
}
