package al.qiri.reader;

import java.text.Normalizer;
import java.util.Locale;

/**
 * Produces a pronunciation-friendly copy of each printed line.
 * The book's visible text and its 219 illustrations are never modified.
 * In particular, text-to-speech engines may interpret FULL CAPITALS or
 * widely spaced letter headings as acronyms and spell them out letter by letter.
 */
public final class SpeechTextNormalizer {
  private SpeechTextNormalizer() {}

  public static String forSpeech(String raw, Locale language) {
    if (raw == null) return "";
    Locale target = language == null ? Locale.ROOT : language;
    String line = Normalizer.normalize(raw, Normalizer.Form.NFC)
        .replace('\u00a0', ' ').trim().replaceAll("\\s+", " ");
    if (line.isEmpty()) return line;

    // Headings rendered as "L E G J E N D A" are a single word, not seven
    // utterances. Do not collapse two-letter initials such as "M V".
    if (looksLikeLetterSpacedWord(line)) {
      StringBuilder word = new StringBuilder();
      int i = 0;
      while (i < line.length()) {
        int cp = line.codePointAt(i);
        if (Character.isLetter(cp)) word.appendCodePoint(cp);
        i += Character.charCount(cp);
      }
      line = word.toString();
    }

    // Some engines spell a whole uppercase title (e.g. "ROZAFA — ...")
    // instead of pronouncing it as ordinary words. The normalization is
    // AUDIO-ONLY; do not change the visual capitalization in the book.
    if (looksLikeCapitalHeading(line)) line = spokenTitleCase(line, target);
    return line;
  }

  private static boolean looksLikeLetterSpacedWord(String line) {
    int letters = 0;
    boolean awaitingSpace = false;
    for (int p = 0; p < line.length();) {
      int cp = line.codePointAt(p);
      p += Character.charCount(cp);
      if (Character.isLetter(cp)) {
        if (awaitingSpace) return false; // two adjacent letters: normal word
        letters++;
        awaitingSpace = true;
      } else if (Character.isWhitespace(cp)) {
        if (!awaitingSpace) return false;
        awaitingSpace = false;
      } else return false; // punctuation: not an isolated spaced heading
    }
    return letters >= 5;
  }

  private static boolean looksLikeCapitalHeading(String line) {
    int letters = 0, uppercase = 0;
    for (int p = 0; p < line.length();) {
      int cp = line.codePointAt(p);
      if (Character.isLetter(cp)) {
        letters++;
        if (Character.isUpperCase(cp)) uppercase++;
      }
      p += Character.charCount(cp);
    }
    return letters >= 5 && uppercase * 100 >= letters * 90;
  }

  private static String spokenTitleCase(String text, Locale locale) {
    // Lower-case the heading first; capitalize each distinct word, including
    // proper names. Locales such as Turkish and French use locale-aware rules.
    String lower = text.toLowerCase(locale);
    StringBuilder out = new StringBuilder(lower.length());
    boolean wordStart = true;
    for (int p = 0; p < lower.length();) {
      int cp = lower.codePointAt(p);
      if (Character.isLetter(cp)) {
        if (wordStart) cp = Character.toTitleCase(cp);
        wordStart = false;
      } else {
        // Apostrophes inside a word don't separate letters for speech.
        if (cp != '\'' && cp != '\u2019') wordStart = true;
      }
      out.appendCodePoint(cp);
      p += Character.charCount(lower.codePointAt(p));
    }
    return out.toString();
  }
}
