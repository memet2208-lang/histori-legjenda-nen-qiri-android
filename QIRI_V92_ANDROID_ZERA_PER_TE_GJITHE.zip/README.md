# QIRI V92 — ZËRA NATYRALË ONLINE PËR TË GJITHË (infrastrukturë)

## Qëllimi

Publikimi i librit Android me zëra natyralë që punojnë për çdo përdorues,
PA çelës API personal, PA kartë krediti dhe PA llogari në Gemini.

**Sqarim:** Kodi Android është gati për transmetim nga një bibliotekë publike,
por zërat nuk janë ende publikisht të disponueshëm: duhet të gjenerohen,
të publikohen online dhe të plotësohet katalogu në GitHub.

## Arkitektura pa shpenzime të detyrueshme

1. Botuesi gjeneron një herë audio me Gemini TTS. Çelësi i tij vendoset vetëm si
   GitHub Actions Secret `GEMINI_API_KEY` (kurrë në APK apo në repo).
2. MP3-të publikohen në një faqe statike HTTPS, p.sh. Cloudflare Pages Free.
3. Një skedar **publik** `QIRI_PUBLIC_AUDIO_CATALOG.json` në **rrënjën e repos së aplikacionit**
   përmban URL bazë dhe pjesët audio për dyfaqëshe/gjuhë.
4. Android merr katalogun dhe transmeton MP3. Për pjesët pa audio përpiqet TTS lokal.
   Nëse edhe ai mungon, shfaq gabim të qartë; nuk pretendon se audio ekziston.
5. Kontrolli i ekranit të kyçur, pauza dhe ndryshimi i dyfaqëshes janë ruajtur.

## Prova pa çelës

`python3 tools/generate_audio.py --lang sq --start 1 --end 3 --dry-run`

## Gjenerimi (botuesi)

Python >=3.10, `pip install google-genai>=2.25.0`, `ffmpeg`.

`GEMINI_API_KEY=<sekret> python3 tools/generate_audio.py --lang sq --start 1 --end 3 --max-generated 4 --base-url https://PROJEKTI.pages.dev/audio`

Zëri shqip përdor **gemini-3.8-flash-tts** sepse **3.8 Flash-Lite nuk ka shqipen në listën zyrtare të gjuhëve**. Pesë gjuhët e tjera
përdorin Flash-Lite. Dialogët që fillojnë me vijë dialogu provohen me zërin `Puck`;
të tjerët me `Kore`. Ky është pilot; kërkohet kontroll dëgjimor para botimit.

Komanda e mësipërme krijon MP3 `public_site/audio/sq/001_000.mp3` etj dhe
përditëson `QIRI_PUBLIC_AUDIO_CATALOG.json`. Katalogu përfshin **vetëm**
dyfaqëshet e gjeneruara krejt, për të shmangur prerjet në mes të leximit.
Rinise disa herë për shkak të kuotave të planit falas. 219×6=1314 dyfaqëshe
nuk do të krijohen me një provë të vetme. Koha dhe ruajtja varen nga gjatësia.

## Publikimi

- Publiko direktorinë `public_site` si aset statik në HTTPS/Cloudflare Pages.
  Vendos URL-në reale te fusha `base_url` e katalogut (jo fushën shembull).
- Vendos `QIRI_PUBLIC_AUDIO_CATALOG.json` në rrënjën e repos ekzistuese
  `memet2208-lang/histori-legjenda-nen-qiri-android` (GitHub public, main).
- Publiko MP3 e reja dhe rifresko katalogun kur përfundon grupin e radhës.
  Android-i e rifreskon katalogun rreth çdo 15 minuta, pa përditësim APK.
- Përdor `QIRI_V92_NDERTO_APK.yml` në `.github/workflows/` dhe ZIP në rrënjën e repos.

## Kufizimet reale

- Plani falas i Gemini ka limite dhe mund të kthejë `429`. Nuk ka garanci që
  të gjithë 1314 titujt do të prodhohen pa pritje; nuk kërkohet kartë nga kodi.
- Cloudflare Pages Free ka kushte / limite të platformës; respektoji.
- Audio e pararegjistruar nuk ndryshon zërin/shpejtësinë si API dinamike;
  butonat A−/A+ të tekstit janë të paprekur.
- APK **nuk është kompajluar/testuar në telefon në këtë ambient**.
- Përgjegjësia për audion dhe të drejtat e publikimit mbetet te botuesi.
