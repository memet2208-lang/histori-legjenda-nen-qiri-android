#!/usr/bin/env python3
"""Generate publish-once mp3 segments for QIRI's PUBLIC audiobook.

Requires a private GEMINI_API_KEY only on the build machine (GitHub Actions secret),
never in Android or a public repo. Supports --dry-run without any network/API key.
Uses Gemini's documented Interactions TTS API, not the legacy generateContent API.
"""
import argparse, base64, hashlib, json, os, pathlib, re, subprocess, sys, time

ROOT=pathlib.Path(__file__).resolve().parents[1]
BOOK=ROOT/'app/src/main/assets/book_texts.json'
SITE=ROOT/'public_site'
CATALOG=ROOT/'QIRI_PUBLIC_AUDIO_CATALOG.json'
LANGS=('sq','it','en','de','fr','es')
STYLES={'sq':'Warm and clear Albanian (Tosk) storytelling, calm natural pace. Read each word, not its letters.',
'it':'Warm Italian storytelling, natural pacing, clear pronunciation, read every word exactly.',
'en':'Warm British-English audiobook narration, natural pacing and pronunciation.',
'de':'Natural literary German narration, warm pacing and clear pronunciation.',
'fr':'Warm French storytelling and natural pronunciation.',
'es':'Warm Spanish storytelling and natural pronunciation.'}

def spoken(s):
    s=' '.join(s.replace('\r',' ').split())
    if s and any(c.isalpha() for c in s) and sum(c.isupper() for c in s if c.isalpha())/max(1,sum(c.isalpha() for c in s))>.93 and len(s)>4:
        # Only normalize *spoken* copy, no change to printed book.
        s=s[:1]+s[1:].lower()
    return s

def parts(text,maximum=1150):
    """Chunk by paragraph and sentence where possible, preserve full text, no truncation."""
    chunks=[]
    for line in text.replace('\r','').split('\n'):
        line=spoken(line)
        if not line:continue
        # Paragraph can contain long dialogues; preserve boundary for voice change.
        pieces=re.split(r'(?<=[.!?…])\s+(?=[A-ZÀ-ÝÇËÄÖÜ])',line)
        unit=''
        for piece in pieces:
            if len(piece)>maximum:
                if unit:chunks.append((unit,unit.lstrip().startswith(('—','–','-'))));unit=''
                words=piece.split();tmp=''
                for word in words:
                    if len(tmp)+len(word)+1>maximum and tmp:
                        chunks.append((tmp,tmp.lstrip().startswith(('—','–','-'))));tmp=''
                    tmp=(tmp+' '+word).strip()
                if tmp:chunks.append((tmp,tmp.lstrip().startswith(('—','–','-'))))
            elif len(unit)+len(piece)+1>maximum and unit:
                chunks.append((unit,unit.lstrip().startswith(('—','–','-'))));unit=piece
            else:unit=(unit+' '+piece).strip()
        if unit:chunks.append((unit,unit.lstrip().startswith(('—','–','-'))))
    return chunks

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--lang',choices=LANGS,default='sq')
    p.add_argument('--start',type=int,default=1)
    p.add_argument('--end',type=int,default=3)
    p.add_argument('--max-generated',type=int,default=6,
        help='Limit of NEW API calls in this run to respect free-tier quotas')
    p.add_argument('--dry-run',action='store_true')
    p.add_argument('--pause',type=float,default=12,help='seconds between Gemini API requests')
    p.add_argument('--base-url',default='https://REPLACE_WITH_YOUR_PAGES_DOMAIN.pages.dev/audio')
    args=p.parse_args()
    book=json.loads(BOOK.read_text(encoding='utf8'))['spreads']
    if not (1<=args.start<=args.end<=len(book)):p.error('spread range must be 1..219')
    if CATALOG.exists():
        catalog=json.loads(CATALOG.read_text('utf8'))
    else:
        catalog={'version':1,'base_url':args.base_url,'tracks':{},'source_hash':{}}
    catalog['base_url']=args.base_url
    catalog.setdefault('source_hash',{})
    catalog.setdefault('tracks',{})
    catalog['tracks'].setdefault(args.lang,{})
    catalog['source_hash'].setdefault(args.lang,{})
    generated=0
    for number in range(args.start,args.end+1):
        page=book[number-1][args.lang]
        text='\n'.join((page.get('left') or '',page.get('right') or ''))
        units=parts(text)
        digest=hashlib.sha256(text.encode('utf8')).hexdigest()
        if args.dry_run:
            print(f'{args.lang} spread {number}/{len(book)}: {len(text)} chars, {len(units)} audio segments, hash {digest[:12]}')
            continue
        existing=(catalog['source_hash'][args.lang].get(str(number))==digest)
        if not existing:
            # Never distribute recordings generated from a previously edited text.
            for old in catalog['tracks'][args.lang].pop(str(number),[]):
                (SITE/'audio'/old).unlink(missing_ok=True)
            catalog['source_hash'][args.lang].pop(str(number),None)
        if existing and all((SITE/'audio'/f).is_file() for f in catalog['tracks'][args.lang].get(str(number),[])):
            print(f'Already complete: {args.lang} {number}')
            continue
        names=[]
        for i,(segment,dialogue) in enumerate(units):
            name=f'{args.lang}/{number:03d}_{i:03d}.mp3'
            dest=SITE/'audio'/name
            names.append(name)
            if dest.is_file():continue
            if generated>=args.max_generated:
                print('Stopped at quota limit; rerun later. This spread is not advertised until complete.')
                return 0
            if not os.getenv('GEMINI_API_KEY'):
                raise SystemExit('GEMINI_API_KEY secret not configured. Use --dry-run to inspect.')
            dest.parent.mkdir(parents=True,exist_ok=True)
            from google import genai
            client=genai.Client(api_key=os.environ['GEMINI_API_KEY'])
            model='gemini-3.8-flash-tts' if args.lang=='sq' else 'gemini-3.8-flash-lite-tts'
            selected_voice='Puck' if dialogue else 'Kore'
            print(f'Generating {args.lang}/{number}, clip {i+1}/{len(units)}, {len(segment)} chars',flush=True)
            try:
                answer=client.interactions.create(
                    model=model,
                    input=[{'type':'user_input','content':[{'type':'text','text':segment,'annotations':[{'type':'speech_metadata','style':STYLES[args.lang]}]}]}],
                    response_format={'type':'audio'},
                    generation_config={'speech_config':[{'voice':selected_voice}]},
                )
                wav=base64.b64decode(answer.output_audio.data)
                if not wav.startswith(b'RIFF'):raise ValueError('API did not return WAV')
                raw=dest.with_suffix('.wav')
                raw.write_bytes(wav)
                try:
                    subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-i',str(raw),'-codec:a','libmp3lame','-b:a','64k',str(dest)],check=True)
                finally:raw.unlink(missing_ok=True)
                generated+=1
                if args.pause:time.sleep(args.pause)
            except Exception as exc:
                print('API unavailable or free quota reached; not publishing an incomplete spread:',exc,file=sys.stderr)
                return 2
        catalog['tracks'][args.lang][str(number)]=names
        catalog['source_hash'][args.lang][str(number)]=digest
        CATALOG.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        print('Complete:',args.lang,number,'clips',len(names))
    return 0

if __name__=='__main__':sys.exit(main())
