# Kontroll redaksional V71 — Histori dhe Legjenda nën Qiri

**APK-ja mbetet për në fund.** Nuk është kompiluar apo ndryshuar projekti Android.

## Ndreqje reale në tekstin e leximit

- **Dyfaqëshja 89**, ana majtas: `Ai mëhoi të kuptonte ciklin e jetës` → `Ai mësoi të kuptonte ciklin e jetës`.
- E konfirmuar duke lexuar tekstin në figurën origjinale `imazhe/080.webp`, ku gabimi **është i shtypur**. Në V71 u korrigj vetëm teksti shqip i mënyrës së leximit dhe një kopje e ndarë e transkriptimit. Masteri V48 dhe fotografia nuk u modifikuan.
- Përkthimet në pesë gjuhë ishin tashmë kuptimisht të sakta dhe nuk u ndryshuan. Ndreqja grafike e figurës 89 mbetet e hapur.

## Çfarë konfirmon inspektimi i katër hartave origjinale

| Dyfaqëshja | Figura | Numra të vjetër të shtypur | Problem grafik |
|---|---|---|---|
| 168 | `159.webp` | **92, 93, 92** | Qytete, pika qytetesh, numra të vjetër; pretendime gjeografike të debatueshme për Pellazgët |
| 169 | `160.webp` | **94, 95, 94** | Qytete dhe numra të vjetër; kufijtë e mbretërive ilire dhe Arbërisë duan kontroll |
| 170 | `161.webp` | **96, 97, 96** | Qytete dhe numra të vjetër; ndryshime kohore të zonave të kontrollit politik |
| 171 | `162.webp` | **98, 99, 98** | Qytete dhe numra të vjetër; dallimi midis 1912/1913 dhe zonave etnike/kufijve shtetërorë |

**Kujdes:** numrat janë të shtypur në vetë skedarët WebP dhe nuk varen nga numërimi dinamik i lexuesit. Nuk mund të korrigjohen vetëm duke ndryshuar JSON-in. Figura e re nuk u gjenerua; për të mos sajuar gjeografinë e lashtë, nuk është zëvendësuar asnjë hartë.

## Kriteret e korrigjimit grafik para botimit

1. Të hiqen vetëm **emrat dhe pikat e qyteteve**, jo emrat e fiseve, deteve, krahinave, shteteve ose legjendat shpjeguese që verifikohen nga burime.
2. Të eliminohen numrat e vjetër të shtypur 92–99, përfshirë numrat e dubluar në skajin e djathtë; numërimi duhet të vijë nga një sistem unik për 173 dyfaqëshet.
3. Të mos përshkruhen territoret e pellazgëve ose kufijtë politikë të periudhave të gjata si fakte të siguruara pa shënime dhe burime të pavarura.
4. Për figurën 89 të ndreqet gabimi tipografik duke ruajtur ilustrimin. Deri atëherë teksti i leximit të jetë autoritativ për këtë fjali.

## Përditësimi offline

Service worker-i i V71 kërkon më parë skedarët WebP të ruajtur në depot V70, V69, V68. Kjo mbron shkarkimin e mëparshëm të përdoruesit, pa garantuar ende funksionim në çdo shfletues: kërkohet testim real në HTTPS dhe në Android.

**Pezull:** miratimi i hartave; vazhdimësia e disa rrëfimeve; korrigjimi grafik i ilustrimit 89; miratimi përfundimtar gjuhësor, testet e zërit, APK-ja.
