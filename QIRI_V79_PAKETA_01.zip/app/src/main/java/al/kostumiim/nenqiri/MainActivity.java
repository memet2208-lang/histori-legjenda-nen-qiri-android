package al.kostumiim.nenqiri;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebChromeClient;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import java.util.ArrayList;
import java.util.Locale;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private WebView web;
  private NarrationBridge narration;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
    web=new WebView(this);setContentView(web);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.getSettings().setAllowContentAccess(false);
    web.getSettings().setAllowFileAccessFromFileURLs(false);
    web.getSettings().setAllowUniversalAccessFromFileURLs(false);
    web.getSettings().setBuiltInZoomControls(false);
    web.setWebChromeClient(new WebChromeClient());
    narration=new NarrationBridge(this,web);
    web.addJavascriptInterface(narration,"QiriNativeTts");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
        Uri uri=request.getUrl(); String scheme=uri.getScheme();
        if ("https".equals(scheme)||"http".equals(scheme)) {
          try {startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}
          return true;
        }
        return false;
      }
    });
    web.loadUrl("file:///android_asset/www/index.html");
  }
  @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(focused)hideBars();}
  private void hideBars(){
    if(Build.VERSION.SDK_INT>=30){WindowInsetsController c=getWindow().getInsetsController();
      if(c!=null){c.hide(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}}
    else getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
  }
  @Override public void onBackPressed(){
    if(web!=null){web.evaluateJavascript("(function(){let a=document.getElementById('audioPanel'),d=document.getElementById('drawer'),f=document.getElementById('fontbox'),b=document.getElementById('book');if(a&&!a.classList.contains('hidden')){document.getElementById('audioToggle').click();return 'x';}if(!d.classList.contains('hidden')){document.getElementById('closeMenu').click();return 'x';}if(!f.classList.contains('hidden')){document.getElementById('closeFonts').click();return 'x';}if(!b.classList.contains('hidden')){if(b.classList.contains('focusMode')){document.getElementById('focusToggle').click();return 'x';}if(b.classList.contains('detailMode')){document.getElementById('detailToggle').click();return 'x';}document.getElementById('home').click();return 'x';}return 'exit';})()",v->{if("\"exit\"".equals(v))finish();});}
    else super.onBackPressed();
  }
  @Override protected void onPause(){if(narration!=null)narration.pause();super.onPause();}
  @Override protected void onDestroy(){if(narration!=null){narration.destroy();narration=null;}if(web!=null){web.removeJavascriptInterface("QiriNativeTts");web.destroy();web=null;}super.onDestroy();}

  public static final class NarrationBridge implements TextToSpeech.OnInitListener {
    private final Activity activity;
    private final WebView web;
    private TextToSpeech engine;
    private volatile boolean ready=false; private boolean paused=false, running=false;
    private int token=0,part=0;
    private final List<String> segments=new ArrayList<>();
    private String pendingText="",pendingLanguage="sq-AL";
    private float rate=0.9f;
    NarrationBridge(Activity activity,WebView web){this.activity=activity;this.web=web;engine=new TextToSpeech(activity,this);}
    private void send(String event){activity.runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.QiriAudio&&window.QiriAudio.nativeEvent("+JSONObject.quote(event)+")",null);});}
    @Override public void onInit(int status){activity.runOnUiThread(()->{ready=status==TextToSpeech.SUCCESS;if(!ready){send("error");return;}if(!pendingText.isEmpty()){String text=pendingText;pendingText="";start(pendingLanguage,text,rate);}});}

    @JavascriptInterface public String availableOfflineVoices(){
      if(!ready || engine==null)return "PENDING";
      Set<Voice> voices=engine.getVoices();
      if(voices==null)return "UNKNOWN";
      String[] languages={"sq-AL","it-IT","en-GB","de-DE","fr-FR","es-ES"};
      StringBuilder result=new StringBuilder();
      for(String language:languages){
        boolean found=false;
        String code=Locale.forLanguageTag(language).getLanguage();
        for(Voice v:voices){
          if(!v.isNetworkConnectionRequired()&&v.getLocale().getLanguage().equals(code)){found=true;break;}
        }
        if(result.length()>0)result.append(';');
        result.append(language).append('=').append(found?'1':'0');
      }
      return result.toString();
    }
    @JavascriptInterface public void speak(String language,String text,double speed){activity.runOnUiThread(()->{
      stopInternal();pendingLanguage=language;pendingText="";rate=(float)Math.max(0.65,Math.min(1.35,speed));
      if(!ready){pendingText=text;return;}start(language,text,rate);
    });}
    private void start(String language,String text,float speed){
      if(engine==null){send("error");return;}
      Locale locale=Locale.forLanguageTag(language);
      int res=engine.setLanguage(locale);
      if(res==TextToSpeech.LANG_MISSING_DATA||res==TextToSpeech.LANG_NOT_SUPPORTED){send("missing_voice");return;}
      Voice offline=null;Set<Voice> voices=engine.getVoices();
      if(voices!=null){for(Voice v:voices){if(!v.isNetworkConnectionRequired()&&v.getLocale().getLanguage().equals(locale.getLanguage())){
          if(offline==null||v.getLocale().toLanguageTag().equalsIgnoreCase(language))offline=v;
      }}}
      if(voices!=null&&offline==null){send("missing_voice");return;}
      if(offline!=null)engine.setVoice(offline);
      engine.setSpeechRate(speed);
      segments.clear();segments.addAll(split(text));part=0;paused=false;running=!segments.isEmpty();token++;
      engine.setOnUtteranceProgressListener(new UtteranceProgressListener(){
        @Override public void onStart(String id){}
        @Override public void onDone(String id){activity.runOnUiThread(()->{
           if(!running||paused||!id.startsWith(token+"-"))return;
           part++;next();
        });}
        @Override public void onError(String id){activity.runOnUiThread(()->{if(id.startsWith(token+"-")){stopInternal();send("error");}});}
      });
      send("reading");next();
    }
    private List<String> split(String text){List<String> chunks=new ArrayList<>();
      for(String paragraph:text.split("\\n+")){
        String p=paragraph.trim();if(p.isEmpty())continue;
        String[] sentences=Pattern.compile("(?<=[.!?…])\\s+").split(p);
        for(String sentence:sentences){String s=sentence.trim();while(s.length()>700){int cut=s.lastIndexOf(' ',700);if(cut<120)cut=700;chunks.add(s.substring(0,cut));s=s.substring(cut).trim();}if(!s.isEmpty())chunks.add(s);}
      }return chunks;
    }
    private void next(){if(!running||paused||engine==null)return;
      if(part>=segments.size()){running=false;send("finished");return;}
      int result=engine.speak(segments.get(part),TextToSpeech.QUEUE_FLUSH,null,token+"-"+part);
      if(result==TextToSpeech.ERROR){stopInternal();send("error");}
    }
    @JavascriptInterface public void pause(){activity.runOnUiThread(()->{if(running&&!paused){paused=true;if(engine!=null)engine.stop();send("paused");}});}
    @JavascriptInterface public void resume(){activity.runOnUiThread(()->{if(running&&paused){paused=false;send("reading");next();}});}
    @JavascriptInterface public void stop(){activity.runOnUiThread(this::stopInternal);}
    private void stopInternal(){token++;running=false;paused=false;segments.clear();part=0;pendingText="";if(engine!=null)engine.stop();}
    void destroy(){stopInternal();if(engine!=null){engine.shutdown();engine=null;}}
  }
}
