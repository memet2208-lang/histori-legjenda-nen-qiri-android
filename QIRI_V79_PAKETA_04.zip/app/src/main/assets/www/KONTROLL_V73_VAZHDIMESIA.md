# V73 — Kontrolli i vazhdimësisë së rrëfimeve

**Burimi V72.** 173 dyfaqëshe, 6 gjuhë. **APK-ja shtyhet.**

## Korrigjime të zbatuara, vetëm në tekstin aktiv

- **34 — Halili dhe Tanusha:** `Kohët e qetësisë ishte` → `Koha e qetësisë ishte` (gramatikë shqipe).
- **35 — Halili dhe Tanusha:** `Pas shpëtimit` → `Pas udhëtimit nëpër male`, sepse shpëtimi dhe kthimi janë përshkruar më parë në dyfaqëshen 33; dyfaqëshja 34 tregon nisjen e një udhëtimi të ri. E përkthyer në të pesë gjuhët.
- **82 — Syri i Kaltër dhe Lubia:** Shtohet kalim që thotë shprehimisht se variantet nuk bien dakord si u largua Lubia. **Nuk është trilluar betejë, vdekje apo mënyrë zhdukjeje**; nuk janë hequr paragrafët e rrëfimit. E përkthyer në pesë gjuhë.
- **84 — Jeta e përditshme:** Fjali kalimtare nga mbyllja e mbrëmjes së legjendave në dyfaqëshen 83 te jeta e përditshme e të parëve. Mbyllja finale e librit në 172 nuk ndryshon. E përkthyer në pesë gjuhë.

**19 ndryshime gjithsej (4 SQ + 15 të huaja)**; regjistri ka tekste ekzakte para/pas.

## Çështje të pambyllura

1. **Gishtoja 38–42:** bashkëpunon me hajdutët, largohet me një monedhë në 41, ndërsa 42 ka papritur thasë me florinj. Duhet vendim për të rishkruar skenën, duke ruajtur figurën ekzistuese nëse përputhet.
2. **Ora/Zana 43–46:** protagonisti në 44 quhet Ora (një djalë), ndërsa në 45 është Leka pa hyrje; figura mitologjike *Ora* ngatërrohet me emrin e protagonistit. Kërkon rishikim për emrat dhe kontinuitetin.
3. **Hartat 168–171:** qytetet, numrat 92–99 dhe kufijtë e pa verifikuar vazhdojnë brenda figurave. Nuk janë hequr me një maskim të pasaktë.
4. **Përputhja ilustrim/tekst:** korrigjimet SQ në 30,34,35,40,82,84,89 mund të mos përputhen me shkrimin e shtypur brenda imazheve. V73 nuk zëvendëson ilustrime të miratuara.
5. **Redaktim për botim:** 5 përkthimet mbeten DRAFT pa miratim nga redaktorë amtarë; kontrolli akademik historik mbetet i hapur.

**Nuk është gati për botim.** Natyra e këtyre korrigjimeve është e kufizuar dhe e gjurmueshme; origjinalet ruhen në paketë.
