# Hartat historike — kontrolli V67 (për botim, pa ndryshime të figurave)

## Gjendja e konfirmuar

Kontroll vizual i imazheve të dyfaqësheve **167–171** në V66. Katër hartat 168–171 kanë emra qytetesh dhe vendbanimesh të integruar në pikselët e ilustrimeve WebP. Kjo bie ndesh me vendimin redaksional të projektit **“qytetet të hiqen nga hartat”**. Heqja kërkon redaktim grafik të kontrolluar të kopjeve të hartave dhe krahasim me hartat e miratuara; nuk duhet kryer me prerje që fshin kufij, emra krahinash ose legjendat. V67 nuk ka ndryshuar asnjë imazh.

## Gjetje sipas dyfaqësheve

- **167 — Dy harta, dy lloje të vërtete:** Harta e rrëfimit legjendar dhe harta reale shpjegohen si të ndryshme. Ruaj dallimin e qartë mes mitit dhe gjeografisë.
- **168 — Pellazgët dhe ilirët:** Hartografia e pellazgëve është hipotezë interpretative e burimeve të lashta, jo kufi territorial i njohur historikisht. Legjenda dhe ngjyrat nuk duhet të sugjerojnë një shtet të dokumentuar me kufij të prerë. Ilirët përfshinin bashkësi/fise dhe kufijtë e shtrirjes historike kanë pasiguri.
- **169 — Mbretëritë ilire / Arbëria mesjetare:** Hartat e shteteve të ndryshme historike dhe principatave duhet të ndajnë datën përkatëse nga hapësira e përafërt. Rajonet dhe sundimet nuk duhen paraqitur si kufij të një shteti të vetëm e të qëndrueshëm.
- **170 — Koha e Skënderbeut / Periudha osmane:** Dallohen territoret e sundimit, aleancat fisnike dhe administrata osmane; kërkon kontroll më vete të vijave dhe legjendës kundrejt burimeve të datuara.
- **171 — Shek. XIX–XX:** **28.11.1912** është shpallja e pavarësisë, por përcaktimi ndërkombëtar i kufijve vijoi gjatë **1913**. Hartat që tregojnë shek. XX duhet të specifikojnë se cilit vit i referohen kufijtë. Nuk duhet të barazohen vendbanimet, përkatësia kombëtare dhe sovraniteti shtetëror.

## Burime referimi dhe kufizimet

1. *Encyclopaedia Britannica (1911), “Pelasgians”* — burime antike dhe përdorime të ndryshme të emrit: https://en.wikisource.org/wiki/1911_Encyclop%C3%A6dia_Britannica/Pelasgians
2. *Encyclopaedia Britannica (1911), “Illyria”* — kufij historikisht të papërcaktuar qartë mes fiseve: https://penelope.uchicago.edu/Thayer/E/Roman/Texts/secondary/EB1911/Illyria%2A.html
3. *Encyclopaedia Britannica (1922), “Albania”* — diskutimi i Konferencës së Londrës dhe kufijve 1912–1913: https://en.wikisource.org/wiki/1922_Encyclop%C3%A6dia_Britannica/Albania
4. *ICA Advances (2019), “Unknown Unknowns in Map Preparation for Historical Atlases”* — rreziqet e kufijve të pasaktë në atlase historike: https://ica-abs.copernicus.org/articles/1/327/2019/index.html

Burimet enciklopedike të fillimshekullit XX janë referenca historike për lexim të mëtejshëm, **jo** zëvendësim i literaturës së sotme shkencore. Ky raport nuk certifikon vijat e kufijve në katër hartat. Nevojitet kontroll nga historian/kartograf dhe verifikim grafik përpara botimit.

## Rregull për ndryshimet grafike

Ruaj figurat origjinale WebP në arkiv. Përgatit kopje të korrigjuara vetëm për **168–171**, hiq nga figura etiketat e qyteteve dhe vendbanimeve (jo titujt, detet, shtetet, epokat apo elementet orientuese); pastaj kontrollo çdo fletë për gabime historike dhe tipografike. Nëse heqja e shkrimeve prish informacionet ose saktësinë, kërko miratimin e një kompozimi të ri kartografik në vend të fshirjes artificiale.
