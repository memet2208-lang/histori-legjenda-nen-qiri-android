package al.qiri.reader;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Native, foreground Android TTS: tries network voices, uses installed fallback, works screen-off. */
public final class NarrationService extends Service {
  public static final String STATUS_EVENT="al.qiri.reader.NARRATION_STATUS";
  public static final String ACTION_PLAY="qiri.PLAY",ACTION_PAUSE="qiri.PAUSE",ACTION_STOP="qiri.STOP",
      ACTION_PAGE="qiri.PAGE",ACTION_LANGUAGE="qiri.LANGUAGE",ACTION_SPEED="qiri.SPEED",
      ACTION_MODE="qiri.MODE",ACTION_NETWORK="qiri.NETWORK";
  private static final String CHANNEL="qiri_narration";
  private final Handler handler=new Handler(Looper.getMainLooper());
  private TextToSpeech tts;
  private JSONArray pages;
  private PowerManager.WakeLock wakeLock;
  private AudioManager audioManager;
  private AudioFocusRequest focusRequest;
  private boolean ready=false,playing=false,paused=false,onlinePreferred=true,networkVoice=false;
  private int page=0,mode=0,part=0,epoch=0,voiceAlternation=0;
  private float speed=1f;
  private String language="sq", voiceInfo="";
  private final List<Segment> segments=new ArrayList<>();
  private List<Voice> possibleVoices=new ArrayList<>();
  private boolean networkFallbackUsed=false;

  private static final class Segment {
    String text;boolean dialogue;
    Segment(String text,boolean dialogue){this.text=text;this.dialogue=dialogue;}
  }
  @Override public void onCreate(){
    super.onCreate();
    try(InputStream in=getAssets().open("book_texts.json")){
      ByteArrayOutputStream o=new ByteArrayOutputStream(); byte[] b=new byte[16384];int n;
      while((n=in.read(b))>0)o.write(b,0,n);
      pages=new JSONObject(o.toString("UTF-8")).getJSONArray("spreads");
    }catch(Exception e){Log.e("QiriAudio","Cannot load book",e);}
    audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
    PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
    wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Qiri::NativeSpeech");
    wakeLock.setReferenceCounted(false);
    makeChannel();
    tts=new TextToSpeech(getApplicationContext(),status->handler.post(()->{
      ready=status==TextToSpeech.SUCCESS;
      if(!ready){abort("Motori i leximit me zë nuk u aktivizua. Kontrollo Speech Services by Google.");return;}
      tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
        @Override public void onStart(String id) {}
        @Override public void onDone(String id){handler.post(()->completed(id));}
        @Override public void onError(String id){handler.post(()->failed(id,"Gabim i motorit TTS"));}
        @Override public void onError(String id,int code){handler.post(()->failed(id,"Gabim TTS: "+code));}
      });
      if(playing&&!paused)beginPage();
    }));
  }
  @Override public int onStartCommand(Intent request,int flags,int startId){
    if(request==null)return START_NOT_STICKY;
    String action=request.getAction();
    int requestedPage=Math.max(0,Math.min(request.getIntExtra("page",page),218));
    String requestedLanguage=request.getStringExtra("lang");
    if(requestedLanguage==null)requestedLanguage=language;
    page=requestedPage;language=requestedLanguage;
    mode=request.getIntExtra("mode",mode);speed=request.getFloatExtra("speed",speed);
    onlinePreferred=request.getBooleanExtra("network",onlinePreferred);
    if(ACTION_PLAY.equals(action)){
      enterForeground(); playing=true;paused=false;networkFallbackUsed=false;
      holdWakeLock();requestAudioFocus();
      if(ready)beginPage();else report("playing","Duke nisur motorin e zërit…");
    } else if(ACTION_STOP.equals(action)){
      quit();
    } else if(ACTION_PAUSE.equals(action)){
      if(playing){if(!paused){paused=true; epoch++;if(tts!=null)tts.stop();releaseWakeLock();report("paused","Leximi në pauzë");}
      else{paused=false;holdWakeLock();if(ready)utter();else report("playing","Duke aktivizuar zërin…");}}
    } else if(ACTION_PAGE.equals(action)||ACTION_LANGUAGE.equals(action)){
      if(playing){epoch++; if(tts!=null)tts.stop();if(ready)beginPage();else report("paused","Dyfaqëshja e zgjedhur: "+(page+1));}
    } else if(ACTION_MODE.equals(action)||ACTION_SPEED.equals(action)||ACTION_NETWORK.equals(action)){
      if(playing&&!paused&&ready){epoch++;tts.stop();if(ACTION_NETWORK.equals(action))pickVoices();utter();}
    }
    return playing?START_STICKY:START_NOT_STICKY;
  }
  private void beginPage(){
    if(pages==null){abort("Teksti i librit nuk u ngarkua");return;}
    epoch++;part=0;voiceAlternation=0;networkFallbackUsed=false;segments.clear();
    if(playing&&!paused){releaseWakeLock();holdWakeLock();}
    try{
      JSONObject row=pages.getJSONObject(page).optJSONObject(language);
      if(row==null){abort("Mungon teksti për gjuhën "+language);return;}
      appendSegments(row.optString("left"));appendSegments(row.optString("right"));
      if(segments.isEmpty()){abort("Faqja nuk ka tekst për të lexuar");return;}
      pickVoices();
      if(possibleVoices.isEmpty()){abort("Mungon zëri "+tag(language)+". Aktivizo/instalo gjuhën në motorin Android TTS.");return;}
      utter();
    }catch(Exception e){abort("Gabim gjatë leximit të tekstit: "+e.getMessage());}
  }
  private void appendSegments(String value){
    String[] lines=value.replace("\r","").split("\n+");
    for(String raw:lines){
      String t=raw.trim();if(t.isEmpty())continue;
      boolean dialogue=t.startsWith("—")||t.startsWith("–")||t.startsWith("-");
      // Chunk for the Android TTS utterance limit. Preserve dialogue boundaries and text.
      String[] words=t.split("\\s+");StringBuilder chunk=new StringBuilder();
      for(String word:words){
        if(chunk.length()>0&&chunk.length()+word.length()+1>270){segments.add(new Segment(chunk.toString(),dialogue));chunk.setLength(0);}
        if(chunk.length()>0)chunk.append(' ');chunk.append(word);
      }
      if(chunk.length()>0)segments.add(new Segment(chunk.toString(),dialogue));
    }
  }
  private String tag(String lang){
    switch(lang){case "it":return "it-IT";case "en":return "en-GB";case "de":return "de-DE";
      case "fr":return "fr-FR";case "es":return "es-ES";default:return "sq-AL";}
  }
  private Locale locale(){return Locale.forLanguageTag(tag(language));}
  private int quality(Voice v){
    int score=0;
    if(v.isNetworkConnectionRequired())score+=onlinePreferred?1000:0;
    else if(!onlinePreferred)score+=600;
    if(v.getLocale().toLanguageTag().equalsIgnoreCase(tag(language)))score+=100;
    score+=v.getQuality()*10;
    String n=v.getName().toLowerCase(Locale.ROOT);
    if(n.contains("neural")||n.contains("natural")||n.contains("enhanced"))score+=40;
    return score;
  }
  private void pickVoices(){
    possibleVoices.clear();
    Locale l=locale();
    try{
      Set<Voice> vs=tts.getVoices();
      if(vs!=null)for(Voice v:vs)if(v.getLocale()!=null && l.getLanguage().equals(v.getLocale().getLanguage()))possibleVoices.add(v);
      Collections.sort(possibleVoices,(a,b)->Integer.compare(quality(b),quality(a)));
    }catch(Exception e){Log.w("QiriAudio","Cannot enumerate installed voices",e);}
    if(possibleVoices.isEmpty()){
      // Android TTS setLanguage fallback only when engine declares THIS language available.
      int can=tts.isLanguageAvailable(l);
      if(can>=TextToSpeech.LANG_AVAILABLE){
        tts.setLanguage(l);Voice basic=tts.getVoice();
        if(basic!=null && basic.getLocale()!=null && l.getLanguage().equals(basic.getLocale().getLanguage()))possibleVoices.add(basic);
      }
    }
  }
  private void utter(){
    if(!playing||paused||!ready)return;
    if(part>=segments.size()){
      if(page+1>=219){playing=false;releaseWakeLock();releaseFocus();report("finished","Fundi i librit");finishForeground();stopSelf();return;}
      page++; beginPage(); return;
    }
    if(possibleVoices.isEmpty()){
      abort("Nuk gjendet zë për "+tag(language)+". Zgjidh Speech Services by Google.");return;
    }
    Segment segment=segments.get(part);
    int voiceIndex=0;
    if(mode==2 && possibleVoices.size()>1)voiceIndex=1;
    if(mode==0 && possibleVoices.size()>1 && segment.dialogue)voiceIndex=voiceAlternation++%2;
    Voice voice=possibleVoices.get(voiceIndex);
    if(tts.setVoice(voice)==TextToSpeech.ERROR){abort("Zëri "+tag(language)+" nuk mund të aktivizohet.");return;}
    networkVoice=voice.isNetworkConnectionRequired();voiceInfo=(networkVoice?"🌐 Zë online":"Zë i pajisjes")+" · "+tag(language);
    tts.setSpeechRate(Math.max(.65f,Math.min(1.4f,speed)));
    tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
    String utteranceId=epoch+"-"+part;
    report("playing",voiceInfo);
    Bundle params=new Bundle();
    int result=tts.speak(segment.text,TextToSpeech.QUEUE_FLUSH,params,utteranceId);
    if(result==TextToSpeech.ERROR)failed(utteranceId,"Motori refuzoi zërin");
  }
  private boolean current(String id){return id!=null&&id.equals(epoch+"-"+part);}
  private void completed(String id){if(!current(id)||!playing||paused)return;part++;utter();}
  private void failed(String id,String message){
    if(!current(id)||!playing)return;
    // Network engines can fail when unavailable. Retry once using an installed local voice.
    if(networkVoice&&!networkFallbackUsed){
      networkFallbackUsed=true;
      List<Voice> locals=new ArrayList<>();for(Voice v:possibleVoices)if(!v.isNetworkConnectionRequired())locals.add(v);
      if(!locals.isEmpty()){ possibleVoices.clear();possibleVoices.addAll(locals);
        epoch++;report("playing","Lidhja e zërit online dështoi; përdoret zëri lokal "+tag(language));utter();return;}
    }
    abort(message+". Kontrollo internetin ose zërat e instaluar për "+tag(language));
  }
  private void holdWakeLock(){if(wakeLock!=null&&!wakeLock.isHeld())wakeLock.acquire(4*60*60*1000L);}
  private void releaseWakeLock(){if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();}
  private void requestAudioFocus(){
    if(audioManager==null)return;
    try{
      focusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
          .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
          .setOnAudioFocusChangeListener(change->{if(change==AudioManager.AUDIOFOCUS_LOSS)handler.post(()->{if(playing&&!paused){paused=true;epoch++;tts.stop();releaseWakeLock();report("paused","Një aplikacion tjetër përdor zërin");}});}).build();
      audioManager.requestAudioFocus(focusRequest);
    }catch(Exception ignored){}
  }
  private void releaseFocus(){try{if(focusRequest!=null&&audioManager!=null)audioManager.abandonAudioFocusRequest(focusRequest);}catch(Exception ignored){}}
  private void report(String status,String msg){
    Intent i=new Intent(STATUS_EVENT).setPackage(getPackageName());
    i.putExtra("status",status);i.putExtra("page",page);i.putExtra("message",msg);
    sendBroadcast(i);
  }
  private void makeChannel(){
    NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Leximi i librit me zë",NotificationManager.IMPORTANCE_LOW));
  }
  private void enterForeground(){
    Intent open=new Intent(this,MainActivity.class);
    PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    Notification n=new Notification.Builder(this,CHANNEL)
        .setSmallIcon(android.R.drawable.ic_media_play)
        .setContentTitle("Histori dhe Legjenda nën Qiri")
        .setContentText("Leximi me zë po vazhdon…")
        .setContentIntent(pi).setOngoing(true).build();
    if(Build.VERSION.SDK_INT>=29)startForeground(874,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    else startForeground(874,n);
  }
  private void finishForeground(){
    if(Build.VERSION.SDK_INT>=24)stopForeground(STOP_FOREGROUND_REMOVE);
    else stopForeground(true);
  }
  private void abort(String message){
    playing=false;paused=false;epoch++;if(tts!=null)tts.stop();releaseWakeLock();releaseFocus();
    report("error",message);finishForeground();stopSelf();
  }
  private void quit(){
    playing=false;paused=false;epoch++;if(tts!=null)tts.stop();releaseWakeLock();releaseFocus();
    report("stopped","Leximi u ndal");finishForeground();stopSelf();
  }
  @Override public void onDestroy(){playing=false;releaseWakeLock();releaseFocus();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
  @Override public IBinder onBind(Intent intent){return null;}
}
