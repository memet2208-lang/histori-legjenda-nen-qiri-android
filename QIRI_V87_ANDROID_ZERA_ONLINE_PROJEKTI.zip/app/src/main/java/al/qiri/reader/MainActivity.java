package al.qiri.reader;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;
import org.json.JSONObject;

/** The illustrated V86 reader is unchanged except for V87's native TTS glue. */
public final class MainActivity extends Activity {
  private WebView web;
  private boolean activeSession = false;
  private int currentPage = 0;
  private String currentLang = "sq";
  private int currentMode = 0;
  private float currentSpeed = 1f;
  private boolean preferNetwork = true;
  private BroadcastReceiver narrationStatus;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    web = new WebView(this);
    setContentView(web);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.getSettings().setAllowFileAccessFromFileURLs(false);
    web.getSettings().setAllowUniversalAccessFromFileURLs(false);
    web.addJavascriptInterface(new ReaderBridge(), "AndroidReader");
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        Uri uri = request.getUrl();
        if ("file".equals(uri.getScheme()) && "android_asset".equals(uri.getPathSegments().isEmpty()?"":uri.getPathSegments().get(0))) return false;
        if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
          try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch(Exception ignored) {} return true;
        }
        return true;
      }
    });
    narrationStatus = new BroadcastReceiver() {
      @Override public void onReceive(Context context, Intent intent) {
        String status = intent.getStringExtra("status");
        String message = intent.getStringExtra("message");
        int page = intent.getIntExtra("page", currentPage);
        if ("stopped".equals(status) || "finished".equals(status) || "error".equals(status)) activeSession=false;
        currentPage=Math.max(0,Math.min(page,218));
        String code="window.QIRI_NATIVE_STATUS&&window.QIRI_NATIVE_STATUS("+
          JSONObject.quote(status==null?"":status)+","+page+","+JSONObject.quote(message==null?"":message)+");";
        web.evaluateJavascript(code, null);
      }
    };
    IntentFilter filter=new IntentFilter(NarrationService.STATUS_EVENT);
    if (Build.VERSION.SDK_INT>=33) registerReceiver(narrationStatus,filter,Context.RECEIVER_NOT_EXPORTED);
    else registerReceiver(narrationStatus,filter);
    web.loadUrl("file:///android_asset/index.html");
  }
  private void dispatch(String action, boolean foreground) {
    Intent i = new Intent(this, NarrationService.class).setAction(action);
    i.putExtra("page",currentPage);
    i.putExtra("lang",currentLang);
    i.putExtra("mode",currentMode);
    i.putExtra("speed",currentSpeed);
    i.putExtra("network",preferNetwork);
    try {
      if(foreground && Build.VERSION.SDK_INT>=26) startForegroundService(i);
      else startService(i);
    } catch(Exception ex) { Log.e("QiriAudio", "Cannot start native TTS", ex); }
  }
  private void external(String url) {
    try {Uri u=Uri.parse(url);String s=u.getScheme();if("https".equals(s)||"http".equals(s))startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
  }
  private final class ReaderBridge {
    @JavascriptInterface public void play(int index,String language,int mode){runOnUiThread(()->{
      currentPage=Math.max(0,Math.min(index,218));currentLang=cleanLanguage(language);currentMode=mode;
      activeSession=true; dispatch(NarrationService.ACTION_PLAY,true);
    });}
    @JavascriptInterface public void onPageChanged(int index){runOnUiThread(()->{
      int newPage=Math.max(0,Math.min(index,218)); if(newPage==currentPage)return;
      currentPage=newPage;
      if(activeSession)dispatch(NarrationService.ACTION_PAGE,false);
    });}
    @JavascriptInterface public void languageChanged(String language){runOnUiThread(()->{
      String n=cleanLanguage(language);if(n.equals(currentLang))return;
      currentLang=n;if(activeSession)dispatch(NarrationService.ACTION_LANGUAGE,false);
    });}
    @JavascriptInterface public void pause(){runOnUiThread(()->{if(activeSession)dispatch(NarrationService.ACTION_PAUSE,false);});}
    @JavascriptInterface public void stop(){runOnUiThread(()->{if(activeSession){dispatch(NarrationService.ACTION_STOP,false);activeSession=false;}});}
    @JavascriptInterface public void speed(float value){runOnUiThread(()->{currentSpeed=Math.max(.65f,Math.min(1.4f,value));if(activeSession)dispatch(NarrationService.ACTION_SPEED,false);});}
    @JavascriptInterface public void voiceMode(int value){runOnUiThread(()->{currentMode=Math.max(0,Math.min(2,value));if(activeSession)dispatch(NarrationService.ACTION_MODE,false);});}
    @JavascriptInterface public void preferOnlineVoices(boolean value){runOnUiThread(()->{preferNetwork=value;if(activeSession)dispatch(NarrationService.ACTION_NETWORK,false);});}
    @JavascriptInterface public void openExternal(String url){runOnUiThread(()->external(url));}
    @JavascriptInterface public void openVoiceSettings(){runOnUiThread(()->{
      try{startActivity(new Intent("com.android.settings.TTS_SETTINGS"));}
      catch(Exception e){try{startActivity(new Intent("android.settings.TTS_SETTINGS"));}
      catch(Exception e2){startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}}
    });}
  }
  private String cleanLanguage(String requested){
    if(requested==null)return "sq";
    switch(requested.toLowerCase(Locale.ROOT)){
      case "sq":case "it":case "en":case "de":case "fr":case "es":return requested.toLowerCase(Locale.ROOT);
      default:return "sq";
    }
  }
  @Override protected void onDestroy(){
    try{unregisterReceiver(narrationStatus);}catch(Exception ignored){}
    if(web!=null){web.removeJavascriptInterface("AndroidReader");web.destroy();}
    super.onDestroy();
  }
}
