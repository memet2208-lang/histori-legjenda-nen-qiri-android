# Histori dhe Legjenda nën Qiri — Android V87

Android WebView offline illustrated book (219 spreads and six languages) with a **native Android TextToSpeech foreground service**.

## Online voice behavior
- Uses Android TextToSpeech engine installed on the device; prefers network voices advertised by `Voice.isNetworkConnectionRequired()`.
- If network voice is not exposed, the highest-scored installed local voice of the same language is used.
- Native language identifiers: `sq-AL`, `it-IT`, `en-GB`, `de-DE`, `fr-FR`, `es-ES`.
- If no German/French voice is installed, reader displays an actionable error; **does not falsely claim those languages play**.
- `AndroidReader` JavaScript bridge synchronizes native speech with page turn, language changes, pause/resume and voice choices.
- Foreground media playback service continues reading and turns pages with screen off, reporting page progress on-screen when the WebView resumes.
- Voice quality and cloud availability depend on installed engine and internet connection. No subscriptions, unofficial free APIs, or secret API keys are embedded in app.

## German / French voices
The built-in `🌐 Zërat / Gjermanisht / Frëngjisht` button opens the device TTS settings to install or activate voices. Exact Android Settings activities vary by manufacturer; the app falls back to the general Settings page if needed.

## Build
Open as Gradle Android project, Java 17, Android SDK 35, Gradle 8.9, or use included GitHub Actions workflow. `gradle :app:assembleDebug` produces `app/build/outputs/apk/debug/app-debug.apk`.

## Important
The repository is build-ready; **APK has not been compiled in the chat environment** (Android SDK unavailable). Install Android Speech Services and select network language voices for DE/FR via Android system Text-to-Speech settings. For portrait the reader requests landscape. Book text and artwork are kept offline in assets.
